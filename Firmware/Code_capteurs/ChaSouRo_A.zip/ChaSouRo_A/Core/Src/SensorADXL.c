/*
 * SensorADXL.c
 *
 *  Created on: Oct 7, 2025
 *      Author: arthu
 */

#include "SensorADXL.h"
