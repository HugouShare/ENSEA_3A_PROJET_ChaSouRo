/*
 * SensorADXL.h
 *
 *  Created on: Oct 7, 2025
 *      Author: arthu
 */

#ifndef INC_SENSORADXL_H_
#define INC_SENSORADXL_H_



#endif /* INC_SENSORADXL_H_ */
